#!/bin/bash
HOST=207.244.229.74
PORT=22
USER=testuser
sshpass -p "*,<R#!$(2udw{Zgz" scp -r $USER@$HOST:/opt/testuser/logfile.log /home/testuser/MyProject/lesson/log/

